
// FIX: Removed outdated mock data (mockAccounts, mockTasks) and their type imports.
// This data was based on an old schema and was causing compilation errors.

export const mockAnalyticsData = [
  { name: '7 days ago', views: 180000 },
  { name: '6 days ago', views: 210000 },
  { name: '5 days ago', views: 250000 },
  { name: '4 days ago', views: 230000 },
  { name: '3 days ago', views: 290000 },
  { name: '2 days ago', views: 350000 },
  { name: 'Yesterday', views: 320000 },
  { name: 'Today', views: 410000 },
];